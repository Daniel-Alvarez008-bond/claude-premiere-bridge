// Pointer swarm: a see-through, click-through layer over the whole screen that shows many labelled mouse pointers "working" at once.
// It only draws; it never clicks or types. Record the screen (or film the laptop) while it runs.
//
//   swiftc -O pointers.swift -o pointers
//   ./pointers                      run until stopped (menu-bar dot > Stop pointers, or Ctrl-C)
//   ./pointers --seconds 30         stop by itself after 30 s
//   ./pointers --count 12           fewer pointers (default: all in zones.json / the built-in layout)
//   ./pointers --speed 1.3          faster or slower movement
//   ./pointers --show-zones         outline the work areas, to line them up with the app underneath
//   ./pointers --zones my.json      use another layout file
//   ./pointers --scripted-only      pointers wait in place and move only when told to (no idle wandering)
//   ./pointers --exit-on-eof        quit when the program driving it over stdin goes away
//
// Work areas come from zones.json next to this file if it exists (fractions of the screen, origin top-left).
// Remote control, one command per line on stdin:
//   go <tag> <zone> <fx> <fy> [carry]   send the pointer called <tag> to a spot in <zone> (fx, fy = 0...1 across / down the zone);
//                                       a tag that does not exist yet gets a new pointer
//   quit

import AppKit
import QuartzCore

struct Zone { let name: String; let rect: CGRect; let drag: Bool; let agents: [String] }

// Default layout = Premiere Pro's "Editing" workspace: source / effect controls top-left, program monitor top-right,
// project bin bottom-left, tools strip, timeline bottom, audio meters far right.
let defaultZones: [Zone] = [
    Zone(name: "timeline", rect: CGRect(x: 0.335, y: 0.615, width: 0.615, height: 0.33), drag: true,
         agents: ["cuts", "whoosh", "impacts", "captions", "music", "trim", "b-roll", "risers", "sync"]),
    Zone(name: "bin", rect: CGRect(x: 0.01, y: 0.62, width: 0.285, height: 0.32), drag: false,
         agents: ["import", "sfx-pick", "footage"]),
    Zone(name: "program", rect: CGRect(x: 0.52, y: 0.09, width: 0.45, height: 0.42), drag: false,
         agents: ["titles", "color"]),
    Zone(name: "controls", rect: CGRect(x: 0.02, y: 0.09, width: 0.44, height: 0.42), drag: true,
         agents: ["zoom", "eq", "keyframes"]),
    Zone(name: "meters", rect: CGRect(x: 0.957, y: 0.63, width: 0.035, height: 0.3), drag: false,
         agents: ["levels"]),
    Zone(name: "tools", rect: CGRect(x: 0.3, y: 0.64, width: 0.028, height: 0.26), drag: false,
         agents: ["razor"]),
]

let palette: [UInt32] = [0x2DE2C5, 0xFF5FB7, 0xFFD23F, 0x7CF25A, 0xFF8A3D, 0xB08CFF, 0x4DA3FF, 0xFF5A5A, 0xC6F432, 0x3FD8FF, 0xFFA8E8, 0x9DF7C8]
func color(_ hex: UInt32, _ a: CGFloat = 1) -> CGColor {
    CGColor(red: CGFloat((hex >> 16) & 255) / 255, green: CGFloat((hex >> 8) & 255) / 255, blue: CGFloat(hex & 255) / 255, alpha: a)
}
func rnd(_ a: CGFloat, _ b: CGFloat) -> CGFloat { CGFloat.random(in: min(a, b)...max(a, b)) }
func ease(_ u: CGFloat) -> CGFloat { u < 0.5 ? 4 * u * u * u : 1 - pow(-2 * u + 2, 3) / 2 }

// ---- arguments
var argCount = 0, argSeconds = 0.0, argSpeed: CGFloat = 1.0, showZones = false, snapshot: String? = nil
var argZones: String? = nil, scriptedOnly = false, exitOnEOF = false
var it = CommandLine.arguments.dropFirst().makeIterator()
while let a = it.next() {
    switch a {
    case "--count": argCount = Int(it.next() ?? "") ?? 0
    case "--seconds": argSeconds = Double(it.next() ?? "") ?? 0
    case "--speed": argSpeed = CGFloat(Double(it.next() ?? "") ?? 1)
    case "--show-zones": showZones = true
    case "--zones": argZones = it.next()
    case "--scripted-only": scriptedOnly = true
    case "--exit-on-eof": exitOnEOF = true
    case "--snapshot": snapshot = it.next()          // debug: save one frame of the layer as a PNG after 1.5 s, then quit
    default: break
    }
}

func loadZones() -> [Zone] {
    let url = argZones.map { URL(fileURLWithPath: $0) } ?? URL(fileURLWithPath: CommandLine.arguments[0]).resolvingSymlinksInPath().deletingLastPathComponent().appendingPathComponent("zones.json")
    guard let data = try? Data(contentsOf: url), let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return defaultZones }
    let zs: [Zone] = arr.compactMap { d in
        guard let n = d["name"] as? String, let x = d["x"] as? Double, let y = d["y"] as? Double, let w = d["w"] as? Double, let h = d["h"] as? Double else { return nil }
        return Zone(name: n, rect: CGRect(x: x, y: y, width: w, height: h), drag: d["drag"] as? Bool ?? false, agents: d["agents"] as? [String] ?? [n])
    }
    return zs.isEmpty ? defaultZones : zs
}

enum Phase { case move, dwell, drag }

final class Agent {
    let layer = CALayer(), arrow = CAShapeLayer(), pill = CALayer(), text = CATextLayer(), chip = CALayer()
    let hex: UInt32, home: Int, name: String
    var scripted = false
    var pos = CGPoint.zero, from = CGPoint.zero, to = CGPoint.zero, ctrl = CGPoint.zero
    var t0: CFTimeInterval = 0, dur: CFTimeInterval = 0.5, phase = Phase.dwell, carrying = false, inHome = true

    init(name: String, hex: UInt32, home: Int, scale: CGFloat) {
        self.hex = hex; self.home = home; self.name = name
        layer.anchorPoint = .zero; layer.bounds = CGRect(x: 0, y: 0, width: 200, height: 60)
        // the pointer: classic arrow, tip at (0,0), body below it (y grows upwards in layer space)
        let p = CGMutablePath()
        p.move(to: CGPoint(x: 0, y: 0)); p.addLine(to: CGPoint(x: 0, y: -19)); p.addLine(to: CGPoint(x: 5.1, y: -14.6))
        p.addLine(to: CGPoint(x: 8.8, y: -22.8)); p.addLine(to: CGPoint(x: 11.9, y: -21.4)); p.addLine(to: CGPoint(x: 8.3, y: -13.4))
        p.addLine(to: CGPoint(x: 14.4, y: -13.4)); p.closeSubpath()
        arrow.path = p; arrow.fillColor = color(hex); arrow.strokeColor = CGColor(gray: 1, alpha: 1); arrow.lineWidth = 1.5; arrow.lineJoin = .round
        arrow.shadowColor = CGColor(gray: 0, alpha: 1); arrow.shadowOpacity = 0.45; arrow.shadowRadius = 3; arrow.shadowOffset = CGSize(width: 0, height: -2)
        // the name tag
        let font = NSFont.systemFont(ofSize: 11, weight: .semibold)
        let w = ceil((name as NSString).size(withAttributes: [.font: font]).width) + 14
        pill.frame = CGRect(x: 13, y: -39, width: w, height: 18); pill.cornerRadius = 9; pill.backgroundColor = color(hex)
        pill.shadowColor = color(hex); pill.shadowOpacity = 0.55; pill.shadowRadius = 5; pill.shadowOffset = .zero
        text.string = name; text.font = font; text.fontSize = 11; text.alignmentMode = .center; text.contentsScale = scale
        text.foregroundColor = CGColor(red: 0.05, green: 0.06, blue: 0.08, alpha: 1); text.frame = CGRect(x: 0, y: 1.5, width: w, height: 15)
        pill.addSublayer(text)
        // a small "clip" carried from the bin to the timeline
        chip.frame = CGRect(x: 16, y: -6, width: 74, height: 15); chip.cornerRadius = 3; chip.backgroundColor = color(hex, 0.55)
        chip.borderColor = color(hex); chip.borderWidth = 1; chip.isHidden = true
        layer.addSublayer(chip); layer.addSublayer(arrow); layer.addSublayer(pill)
    }
}

final class Swarm: NSObject {
    let root: CALayer, size: CGSize, zones: [Zone], scale: CGFloat
    var agents: [Agent] = []
    var timer: Timer?
    var k = 0

    init(root: CALayer, size: CGSize, scale: CGFloat) {
        self.root = root; self.size = size; self.scale = scale; zones = loadZones()
        super.init()
        for (zi, z) in zones.enumerated() { for name in z.agents {
            let a = Agent(name: name, hex: palette[k % palette.count], home: zi, scale: scale); k += 1
            a.pos = point(in: zi); a.layer.position = a.pos; agents.append(a)
        } }
        if argCount > 0 && argCount < agents.count { agents.shuffle(); agents = Array(agents.prefix(argCount)) }
        if showZones { for z in zones {
            let l = CAShapeLayer(); l.path = CGPath(rect: px(z.rect), transform: nil); l.fillColor = CGColor(gray: 1, alpha: 0.05)
            l.strokeColor = CGColor(red: 1, green: 0.3, blue: 0.3, alpha: 0.9); l.lineWidth = 2; l.lineDashPattern = [8, 6]; root.addSublayer(l)
        } }
        for a in agents { root.addSublayer(a.layer); next(a, now: CACurrentMediaTime() + Double(rnd(0, 0.6))) }
        timer = Timer(timeInterval: 1.0 / 60.0, repeats: true) { [weak self] _ in self?.tick() }
        RunLoop.main.add(timer!, forMode: .common)
    }

    func px(_ r: CGRect) -> CGRect { CGRect(x: r.minX * size.width, y: (1 - r.minY - r.height) * size.height, width: r.width * size.width, height: r.height * size.height) }   // zones are top-left based, layers bottom-left
    func point(in zi: Int) -> CGPoint { let r = px(zones[zi].rect); return CGPoint(x: rnd(r.minX, r.maxX), y: rnd(r.minY, r.maxY)) }

    func travel(_ a: Agent, to p: CGPoint, now: CFTimeInterval, speed: CGFloat) {
        a.from = a.pos; a.to = p
        let dx = p.x - a.pos.x, dy = p.y - a.pos.y, d = max(1, hypot(dx, dy)), bend = rnd(-0.2, 0.2)
        a.ctrl = CGPoint(x: (a.pos.x + p.x) / 2 - dy * bend, y: (a.pos.y + p.y) / 2 + dx * bend)
        a.dur = Double(max(0.16, min(0.95, d / speed + 0.1)) / argSpeed); a.t0 = now; a.phase = .move
    }

    func next(_ a: Agent, now: CFTimeInterval) {
        let tl = zones.firstIndex { $0.name == "timeline" }
        if a.carrying { a.carrying = false; a.chip.isHidden = true }                                   // the clip was dropped
        if scriptedOnly { a.dur = 0.5; a.t0 = now; a.phase = .dwell; return }                           // wait for the next command
        if zones[a.home].name == "bin", a.inHome, let t = tl, rnd(0, 1) < 0.4 {                         // carry a clip from the bin to the timeline
            a.carrying = true; a.chip.isHidden = false; a.inHome = false
            travel(a, to: point(in: t), now: now, speed: 1500); return
        }
        a.inHome = true
        travel(a, to: point(in: a.home), now: now, speed: rnd(1300, 2100))
    }

    /// "go <tag> <zone> <fx> <fy> [carry]": send the pointer with that tag to a spot inside a zone (fx, fy = 0...1 across / down the zone).
    /// "quit": stop.
    func command(_ line: String) {
        let w = line.split(separator: " ").map(String.init)
        if w.first == "quit" { NSApp.terminate(nil); return }
        guard w.count >= 5, w[0] == "go", let zi = zones.firstIndex(where: { $0.name == w[2] }), let fx = Double(w[3]), let fy = Double(w[4]) else { return }
        let a: Agent
        if let found = agents.first(where: { $0.name == w[1] }) { a = found } else {                    // a new tag: give it its own pointer
            a = Agent(name: w[1], hex: palette[k % palette.count], home: zi, scale: scale); k += 1
            a.pos = point(in: zi); a.layer.position = a.pos; agents.append(a); root.addSublayer(a.layer)
        }
        let r = px(zones[zi].rect)
        let p = CGPoint(x: r.minX + CGFloat(fx) * r.width, y: r.maxY - CGFloat(fy) * r.height)
        a.carrying = w.count > 5 && w[5] == "carry"; a.chip.isHidden = !a.carrying; a.inHome = (zi == a.home); a.scripted = true
        travel(a, to: p, now: CACurrentMediaTime(), speed: 2600)
    }

    func ripple(at p: CGPoint, hex: UInt32) {
        let r = CAShapeLayer(); r.path = CGPath(ellipseIn: CGRect(x: -13, y: -13, width: 26, height: 26), transform: nil)
        r.fillColor = color(hex, 0.18); r.strokeColor = color(hex); r.lineWidth = 1.6; r.position = p; r.opacity = 0
        root.insertSublayer(r, at: 0)
        CATransaction.begin(); CATransaction.setCompletionBlock { r.removeFromSuperlayer() }
        let s = CABasicAnimation(keyPath: "transform.scale"); s.fromValue = 0.25; s.toValue = 1.5
        let o = CABasicAnimation(keyPath: "opacity"); o.fromValue = 0.95; o.toValue = 0
        let g = CAAnimationGroup(); g.animations = [s, o]; g.duration = 0.38; g.timingFunction = CAMediaTimingFunction(name: .easeOut)
        r.add(g, forKey: "r"); CATransaction.commit()
    }

    func tick() {
        let now = CACurrentMediaTime()
        CATransaction.begin(); CATransaction.setDisableActions(true)
        for a in agents {
            let u = CGFloat(min(1, max(0, (now - a.t0) / a.dur)))
            switch a.phase {
            case .move:
                let e = ease(u), m = 1 - e
                a.pos = CGPoint(x: m * m * a.from.x + 2 * m * e * a.ctrl.x + e * e * a.to.x, y: m * m * a.from.y + 2 * m * e * a.ctrl.y + e * e * a.to.y)
                if u >= 1 {
                    ripple(at: a.pos, hex: a.hex)
                    let z = zones[a.inHome ? a.home : (zones.firstIndex { $0.name == "timeline" } ?? a.home)]
                    if a.scripted { a.scripted = false; a.dur = Double(rnd(0.25, 0.5)); a.t0 = now; a.phase = .dwell }
                    else if z.drag && !a.carrying && rnd(0, 1) < 0.55 {                                      // drag: trim a clip, pull a slider
                        let r = px(z.rect); a.from = a.pos
                        a.to = CGPoint(x: min(r.maxX, max(r.minX, a.pos.x + rnd(40, 230) * (Bool.random() ? 1 : -1))), y: a.pos.y)
                        a.dur = Double(rnd(0.35, 1.0) / argSpeed); a.t0 = now; a.phase = .drag
                    } else { a.dur = Double(rnd(0.08, 0.5) / argSpeed); a.t0 = now; a.phase = .dwell }
                }
            case .drag:
                let e = ease(u); a.pos = CGPoint(x: a.from.x + (a.to.x - a.from.x) * e, y: a.from.y)
                if u >= 1 { a.dur = Double(rnd(0.06, 0.3) / argSpeed); a.t0 = now; a.phase = .dwell }
            case .dwell:
                if u >= 1 { next(a, now: now) }
            }
            a.layer.position = a.pos
        }
        CATransaction.commit()
    }
}

final class Delegate: NSObject, NSApplicationDelegate {
    var win: NSWindow!, swarm: Swarm!, item: NSStatusItem!
    func applicationDidFinishLaunching(_ n: Notification) {
        let screen = NSScreen.main!
        win = NSWindow(contentRect: screen.frame, styleMask: .borderless, backing: .buffered, defer: false)
        win.isOpaque = false; win.backgroundColor = .clear; win.hasShadow = false
        win.ignoresMouseEvents = true                                   // clicks go straight through to the app underneath
        win.level = NSWindow.Level(rawValue: Int(CGWindowLevelForKey(.screenSaverWindow)))
        win.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]
        let v = NSView(frame: CGRect(origin: .zero, size: screen.frame.size)); v.wantsLayer = true
        win.contentView = v; win.orderFrontRegardless()
        swarm = Swarm(root: v.layer!, size: screen.frame.size, scale: screen.backingScaleFactor)
        item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength); item.button?.title = "●"
        let menu = NSMenu(); menu.addItem(NSMenuItem(title: "Stop pointers", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")); item.menu = menu
        if let path = snapshot { DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            let sz = screen.frame.size, sc: CGFloat = 2
            let ctx = CGContext(data: nil, width: Int(sz.width * sc), height: Int(sz.height * sc), bitsPerComponent: 8, bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
            ctx.setFillColor(CGColor(red: 0.12, green: 0.13, blue: 0.16, alpha: 1)); ctx.fill(CGRect(x: 0, y: 0, width: sz.width * sc, height: sz.height * sc))
            ctx.scaleBy(x: sc, y: sc); v.layer!.render(in: ctx)
            let rep = NSBitmapImageRep(cgImage: ctx.makeImage()!); try? rep.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: path)); NSApp.terminate(nil)
        } }
        Thread.detachNewThread { [weak self] in                         // remote control over stdin (see Swarm.command)
            while let line = readLine() { DispatchQueue.main.async { self?.swarm.command(line) } }
            if exitOnEOF { DispatchQueue.main.async { NSApp.terminate(nil) } }
        }
        if argSeconds > 0 { DispatchQueue.main.asyncAfter(deadline: .now() + argSeconds) { NSApp.terminate(nil) } }
    }
}

let app = NSApplication.shared
let delegate = Delegate()
app.delegate = delegate
app.setActivationPolicy(.accessory)
app.run()
