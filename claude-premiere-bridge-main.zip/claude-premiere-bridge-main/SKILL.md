---
name: premiere-bridge
description: Edit video inside Adobe Premiere Pro, live, through the local "Claude Bridge" panel, with a swarm of labelled mouse pointers on screen showing every edit as it happens. Use whenever the user wants something done in Premiere Pro - "edit this", "edit this video", "cut the pauses", "add captions", "add transitions / zooms / b-roll / sound effects / music", "colour grade this", "export it", "what's on my timeline" - or mentions Premiere, the Claude Bridge, the pointers, the pointer swarm or multi-cursor editing. Pointers are on by default for every edit; leave them out only when the user says so.
---

# Premiere Bridge

You edit in the user's real Premiere Pro. A small panel inside Premiere ("Claude Bridge") listens on `http://127.0.0.1:3999` and runs the ExtendScript you send it. While you edit, a see-through overlay shows one labelled mouse pointer per job ("cuts", "captions", "music", ...) moving to the spot each edit lands, so the user can watch and record it.

The pointers are a picture of the work, not the work. They never click. The edits are made by your script, and each pointer is sent to where its edit happens. Say so plainly if the user asks how it works.

Paths below are relative to this skill's folder.

| File | What it is |
|---|---|
| `scripts/ppro.py` | The client: `ping`, `info`, `eval`, and the `Session` class that runs an edit with pointers |
| `references/extendscript.md` | Recipes that were run and checked in Premiere Pro 2026, and the traps |
| `references/pointers.md` | Pointer tags, panels, lining the overlay up with the screen |
| `examples/showcase.py` | A complete edit script to copy from, and a one-command demo |
| `install.sh` | Installs the panel and builds the overlay (macOS) |

## Every edit goes like this

1. **Check the link.** `python3 scripts/ppro.py ping`. If it fails, it prints what the user must do (open Premiere with a project, then Window > Extensions > Claude Bridge). If the panel was never installed, run `./install.sh` and ask the user to quit and reopen Premiere; you cannot open the panel for them.
2. **Look before you touch.** `python3 scripts/ppro.py info` lists the project, every sequence (frame rate, length, clips per track) and the bin items with their file paths.
3. **Understand the footage.** For anything with speech, transcribe the source file with word timings (for example `whisper <file> --model small --word_timestamps True --output_format json`, if whisper is installed). Cuts, captions and sound effects should land on words and pauses, not on a fixed grid. Look at frames with ffmpeg when the picture matters.
4. **Say the plan in two or three lines**, then build what the edit needs (caption PNGs sized to the sequence, sound effects, b-roll the user gave you).
5. **Work on a copy** unless the user wants the open sequence changed: duplicate it first (recipe in `references/extendscript.md`), so the original stays as it was.
6. **Run the edit through `Session`**, so the pointers show it (next section).
7. **Check the result** by reading the timeline back (clip counts, times), then report what was done and any step that failed. Do not save the project or export unless asked.

## Running an edit (pointers on by default)

Write the edit as a short Python script and run it:

```python
import sys; sys.path.insert(0, '<skill folder>/scripts')
from ppro import Session

with Session(wait=3) as s:                      # pointers appear, idle 3 s, then the edit starts
    for t in (4.2, 9.8, 15.1):                  # one step = one pointer move + one edit
        s.step('cuts', 'head(%.2f); return razor(0, %.2f);' % (t, t), track='V1', at=t)
    s.step('captions', 'return put("v", 1, "cap_001.png", 4.2, 0, 1.6);', track='V2', at=4.2, carry=True)
    s.step('color', 'var it=qeAt("v",0,5); it.addVideoEffect(qe.project.getVideoEffectByName("Lumetri Color")); return "ok";', panel='program')
# prints: N edits (N steps) in X s, problems: 0
```

- `s.step(tag, body, ...)`: `tag` is the pointer's label (any short word; a new word gets a new pointer). `body` is the inside of an ExtendScript function: use the helpers from `ppro.py` (`seq`, `findItem`, `put`, `razor`, `cutOut`, `clipAt`, `qeAt`, `prop`, `head`, `tc`, `addTracks`, ...) and `return` a string.
- Say where the edit happens, so the pointer goes there: `track='V2', at=12.5` for the timeline, or `panel='bin' | 'program' | 'controls' | 'meters' | 'tools'` for the other panels. `carry=True` makes the pointer drag a clip chip (use it for anything dropped on the timeline).
- A step whose result starts with `ERR` is counted in `s.problems` and the edit continues. Read the summary line; never report an edit as done when it shows problems.
- Give each kind of work its own tag and keep steps small (one cut, one caption, one sound). Many small steps across many tags is what makes the screen look like a team at work. Order the steps the way an editor would: structure, picture, words, polish, sound.
- `Session(wait=5)` gives the user time to press record; `pace=2` slows everything down; `sequence='Name'` picks a sequence.
- **Turn pointers off only when asked** ("no pointers", "without the animation"): `Session(pointers=False)` or `PPRO_POINTERS=0`. On Windows, or with no Swift compiler, the overlay is skipped with a one-line notice and the edit still runs.
- For the pointers to line up, Premiere should be full screen in the default **Editing** workspace with the whole sequence visible in the timeline (the `\` key). If they look off, see `references/pointers.md`.
- Before a run the user will record, tell them in one line what will and will not happen (for example "pointers plus the real edit, about 30 seconds").

One-off questions and single changes do not need a script: `python3 scripts/ppro.py eval '<ExtendScript>'`.

## ExtendScript rules that save you an hour

- The engine is old JavaScript: `var` and `function` only. No `let`, `const`, arrow functions or template strings. Return plain strings, not objects.
- Times are in seconds for most calls, in ticks (254016000000 per second) as strings for a few, and as timecode strings for the QE razor. Use the helpers `head()`, `tc()`, `razor()` instead of converting by hand.
- A bare `EvalScript error.` means a syntax error or an exception outside try/catch. `Session.step` and `ppro.js()` wrap your body in try/catch and give you `ERR <message>` instead.
- `qe.*` (transitions, effects, razor, adding tracks) always acts on the **active** sequence. `Session(sequence=...)` makes it active for you.
- When removing several sections, go from the end of the timeline to the start, so earlier times stay valid.
- Read `references/extendscript.md` before writing anything it covers. Those calls were checked; guessing other signatures usually costs more time than testing one in `eval` first.

## Try it

`python3 examples/showcase.py` edits a copy of the open sequence (markers, cuts, transitions, zooms, colour, voice effects) with the pointers on. Add `--transcript words.json` for pause-based cuts and word captions.
