#!/usr/bin/env python3
"""A complete example edit, and a quick way to see the bridge and the pointers working.

Open a sequence in Premiere with a clip on V1 (a talking-head clip is ideal), then:

  python3 examples/showcase.py                              markers, cuts, transitions, zooms, colour, voice effects
  python3 examples/showcase.py --transcript words.json      also cuts on the speaker's pauses and adds word captions
                                                            (words.json = whisper --word_timestamps True --output_format json)
  flags: --no-pointers   --wait 5 (seconds before the first edit)   --pace 2 (slower)   --in-place (edit the open sequence itself)

By default the open sequence is duplicated and the copy is edited, so the original stays as it was.
The cuts are video-only razor cuts on V1: nothing is removed and nothing moves in time.
"""
import argparse, json, pathlib, sys, tempfile

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / 'scripts'))
from ppro import Session, BridgeError


def words(path):
    out = []
    for s in json.load(open(path))['segments']:
        for w in s.get('words', []):
            t = w['word'].strip()
            if t: out.append({'t': t, 's': w['start'], 'e': w['end']})
    return out


def phrases(W):
    """Caption cards: up to 3 words, broken at punctuation and at pauses."""
    out, cur = [], []
    for i, w in enumerate(W):
        cur.append(w); nxt = W[i + 1] if i + 1 < len(W) else None
        if len(cur) == 3 or w['t'][-1] in ',.?!' or nxt is None or nxt['s'] - w['e'] > 0.35:
            out.append({'text': ' '.join(x['t'].strip(',.?!') for x in cur).upper(), 's': cur[0]['s'], 'e': cur[-1]['e']}); cur = []
    for i, c in enumerate(out): c['e'] = min(out[i + 1]['s'], c['e'] + 0.3) if i + 1 < len(out) else c['e'] + 0.3
    return [c for c in out if c['e'] - c['s'] > 0.12]


def pause_cuts(W, total, n):
    """Cut where the speaker pauses: the longest gaps between words, at least 1.2 s apart."""
    gaps = sorted(((b['s'] - a['e'], (a['e'] + b['s']) / 2) for a, b in zip(W, W[1:])), reverse=True); out = []
    for g, t in gaps:
        if len(out) < n and all(abs(t - o) > 1.2 for o in out) and 1.0 < t < total - 1.0: out.append(round(t, 2))
    return sorted(out)


def even_cuts(total):
    out, t, k = [], 0.0, 0
    while True:
        t += (2.6, 3.4, 2.2, 3.9)[k % 4]; k += 1
        if t > total - 1.0 or len(out) >= 40: return out
        out.append(round(t, 2))


def render_captions(cards, w, h, folder):
    """One transparent PNG per caption card, sized to the sequence. Needs Pillow; returns [] without it."""
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        print('captions skipped: pip3 install Pillow'); return []
    size = max(28, round(h * 0.075)); font = None
    for f in ('/System/Library/Fonts/Supplemental/Arial Bold.ttf', 'C:/Windows/Fonts/arialbd.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'):
        if pathlib.Path(f).exists(): font = ImageFont.truetype(f, size); break
    if font is None: font = ImageFont.load_default()
    files = []
    for i, c in enumerate(cards, 1):
        im = Image.new('RGBA', (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im); ws = c['text'].split(' '); hot = max(ws, key=len)
        sp = d.textlength(' ', font=font); x = (w - (sum(d.textlength(t, font=font) for t in ws) + sp * (len(ws) - 1))) / 2
        for t in ws:
            d.text((x, h * 0.78), t, font=font, fill=(255, 214, 10, 255) if t == hot else (255, 255, 255, 255), stroke_width=max(3, size // 10), stroke_fill=(0, 0, 0, 255)); x += d.textlength(t, font=font) + sp
        p = folder / ('cap_%03d.png' % i); im.save(p); files.append(p)
    return files


def main():
    ap = argparse.ArgumentParser(description='Showcase edit on the open Premiere sequence.')
    ap.add_argument('--transcript'); ap.add_argument('--no-pointers', action='store_true'); ap.add_argument('--in-place', action='store_true')
    ap.add_argument('--wait', type=float, default=3.0); ap.add_argument('--pace', type=float, default=1.0)
    a = ap.parse_args()

    with Session(pointers=not a.no_pointers, wait=a.wait, pace=a.pace) as s:
        if not a.in_place:                                   # work on a copy
            r = s.js('var o=seq();var ss=app.project.sequences;var old="|";for(var i=0;i<ss.numSequences;i++){old+=ss[i].sequenceID+"|";}o.clone();var c=null;for(var j=0;j<ss.numSequences;j++){if(old.indexOf("|"+ss[j].sequenceID+"|")<0){c=ss[j];}}if(!c){return "ERR could not duplicate the sequence";}c.name=o.name+" (Claude edit)";app.project.activeSequence=c;return c.name;')
            if r.startswith('ERR'): raise BridgeError(r)
            print('editing a copy:', r)
        s.refresh(); D = s.duration
        if s.js('return String(seq().videoTracks[0].clips.numItems);') == '0': raise BridgeError('Put a clip on V1 of the open sequence first.')
        W = [w for w in words(a.transcript) if w['e'] < D] if a.transcript else []
        cuts = pause_cuts(W, D, 30) if W else even_cuts(D)
        size = s.js('return seq().frameSizeHorizontal+"x"+seq().frameSizeVertical;').split('x')

        # structure: markers, then the cuts
        for i in range(5):
            t = i * D / 5
            s.step('markers', 'var m=seq().markers.createMarker(%.3f);m.name="Part %d";m.setColorByIndex(%d,0);head(%.3f);return "ok";' % (t, i + 1, i, t), track='V1', at=t, y=0.0, pause=0.09)
        for t in cuts:
            s.step('cuts', 'head(%.3f);return razor(0,%.3f);' % (t, t), track='V1', at=t, pause=0.09)

        # picture: transitions on every second cut, a slow push-in on some pieces, colour on a few
        for t in cuts[::2]:
            s.step('transitions', 'var it=qeAt("v",0,%.3f);if(!it){return "ERR no clip";}it.addTransition(qe.project.getVideoTransitionByName("Cross Dissolve"),true,tc(0.4));head(%.3f);return "ok";' % (t - 0.2, t), track='V1', at=t, pause=0.1)
        for i, t in enumerate(cuts[1::3]):
            sc = (112, 118, 110, 116)[i % 4]
            s.step('zoom', '''var c=clipAt("v",0,%.3f);if(!c){return "ERR no clip";}sel(c);var p=prop(c,1,"Scale");if(!p){return "ERR no Scale";}
p.setTimeVarying(true);var t0=c.inPoint.seconds;p.addKey(t0+0.05);p.setValueAtKey(t0+0.05,100,true);p.addKey(t0+0.6);p.setValueAtKey(t0+0.6,%d,true);head(%.3f);return "ok";''' % (t + 0.4, sc, t + 0.6),
                   panel='controls', x=0.3, y=0.25 + 0.06 * (i % 6), label='zoom keyframes', pause=0.12)
        for i, t in enumerate(cuts[2::5]):
            s.step('color', 'var c=clipAt("v",0,%.3f);if(c){sel(c);}var it=qeAt("v",0,%.3f);if(!it){return "ERR no clip";}it.addVideoEffect(qe.project.getVideoEffectByName("Lumetri Color"));head(%.3f);return "ok";' % (t + 0.6, t + 0.6, t + 0.6),
                   panel='program', x=0.5, y=0.4 + 0.05 * (i % 4), label='lumetri', pause=0.12)

        # words: a caption card per phrase on V2
        if W:
            folder = pathlib.Path(tempfile.mkdtemp(prefix='claude-captions-')); cards = phrases(W); files = render_captions(cards, int(size[0]), int(size[1]), folder)
            if files:
                s.step('import', 'app.project.importFiles([%s],true,app.project.rootItem,false);return addTracks(2,0);' % ','.join('"%s"' % f.as_posix() for f in files), panel='bin', label='import captions', timeout=300)
                s.refresh()
                for c, f in zip(cards, files):
                    s.step('captions', 'var r=put("v",1,"%s",%.3f,0,%.3f);head(%.3f);return r;' % (f.name, c['s'], c['e'] - c['s'], c['s'] + 0.1), track='V2', at=c['s'], carry=True, label='caption', pause=0.06)

        # sound: a voice chain on the first audio clip
        if s.js('return String(seq().audioTracks.numTracks>0?seq().audioTracks[0].clips.numItems:0);') != '0':
            for i, fx in enumerate(('Parametric Equalizer', 'DeEsser', 'Hard Limiter')):
                s.step('eq' if i == 0 else 'levels', 'var c=track("a",0).clips[0];sel(c);var it=qeAt("a",0,c.start.seconds+0.01);if(!it){return "ERR no clip";}it.addAudioEffect(qe.project.getAudioEffectByName("%s"));return "ok";' % fx,
                       panel='controls' if i == 0 else 'meters', label='voice ' + fx, pause=0.15)
        s.step('preview', 'head(0);return "ok";', panel='program', label='done', pause=0.1)
        print('timeline:', s.js('var s=seq();var o="";for(var i=0;i<s.videoTracks.numTracks;i++){o+="V"+(i+1)+"="+s.videoTracks[i].clips.numItems+" clips/"+s.videoTracks[i].transitions.numItems+" transitions  ";}for(var j=0;j<s.audioTracks.numTracks;j++){o+="A"+(j+1)+"="+s.audioTracks[j].clips.numItems+"  ";}return o+"markers="+s.markers.numMarkers;'))


if __name__ == '__main__':
    try:
        main()
    except BridgeError as e:
        print(e); sys.exit(1)
