#!/usr/bin/env python3
"""Claude <-> Premiere Pro bridge client. Standard library only.

The "Claude Bridge" panel inside Premiere runs a small HTTP server on 127.0.0.1:3999 and executes the ExtendScript it is sent.
This file is the other end: it sends the script, and it runs the pointer overlay so every edit is shown on screen as it happens.

Command line:
  python3 ppro.py ping                 is Premiere + the panel answering?
  python3 ppro.py info                 project, sequences, tracks, bin items
  python3 ppro.py eval 'app.version'   run one ExtendScript expression
  python3 ppro.py eval -f script.jsx   run a script file
  python3 ppro.py pointers [flags]     only the pointer overlay (flags go to the overlay, e.g. --seconds 20 --show-zones)

In an edit script (pointers are ON unless you pass pointers=False or set PPRO_POINTERS=0):

  import sys; sys.path.insert(0, '<this folder>')
  from ppro import Session
  with Session() as s:
      s.step('cuts', 'return razor(0, 12.4);', track='V1', at=12.4)
      s.step('color', 'var c=clipAt("v",0,3); sel(c); return "ok";', panel='program')

Each step moves one labelled pointer to the place the edit happens, then runs the ExtendScript body.
The body is the inside of a function: it can use the helpers in PRELUDE and must `return` a string.
"""
import json, os, pathlib, platform, random, shutil, subprocess, sys, time, urllib.error, urllib.request

SKILL = pathlib.Path(__file__).resolve().parent.parent
BRIDGE = os.environ.get('PPRO_BRIDGE', 'http://127.0.0.1:3999')
TICKS = 254016000000          # Premiere's time unit: ticks per second

# ExtendScript helpers sent in front of every script. Premiere's engine is old: no JSON, no let/const/arrow functions.
PRELUDE = '''
var TICKS=254016000000;var SEQNAME="%SEQ%";
function seq(){if(SEQNAME==""){return app.project.activeSequence;}var s=app.project.sequences;for(var i=0;i<s.numSequences;i++){if(s[i].name==SEQNAME){return s[i];}}return null;}
function findItem(name){function walk(b){for(var i=0;i<b.children.numItems;i++){var c=b.children[i];if(c.name==name){return c;}if(c.type==2){var f=walk(c);if(f){return f;}}}return null;}return walk(app.project.rootItem);}
function fps(){return TICKS/Number(seq().timebase);}
function tc(sec){var f=fps();var n=Math.round(f);var fr=Math.round(sec*f);function p(x){return (x<10?"0":"")+x;}var s=Math.floor(fr/n);return p(Math.floor(s/3600))+":"+p(Math.floor(s/60)%60)+":"+p(s%60)+":"+p(fr%n);}
function head(sec){try{seq().setPlayerPosition(String(Math.round(sec*TICKS)));}catch(e){}}
function track(kind,i){return (kind=="v")?seq().videoTracks[i]:seq().audioTracks[i];}
function put(kind,ti,name,at,inS,outS){var it=findItem(name);if(!it){return "ERR missing "+name;}if(outS>0){it.setInPoint(inS,4);it.setOutPoint(outS,4);}else{it.clearInPoint(4);it.clearOutPoint(4);}track(kind,ti).overwriteClip(it,at);return "ok";}
function clipAt(kind,ti,sec){var t=track(kind,ti);for(var i=0;i<t.clips.numItems;i++){var c=t.clips[i];if(c.start.seconds<=sec+0.001&&c.end.seconds>sec+0.001){return c;}}return null;}
function qeSeq(){app.enableQE();return qe.project.getActiveSequence();}
function qeAt(kind,ti,sec){var s=qeSeq();var t=(kind=="v")?s.getVideoTrackAt(ti):s.getAudioTrackAt(ti);for(var i=0;i<t.numItems;i++){var it=t.getItemAt(i);if(it&&it.type=="Clip"){if(it.start.secs<=sec+0.001&&it.end.secs>sec+0.001){return it;}}}return null;}
function sel(c){try{c.setSelected(1,1);}catch(e){}}
function razor(ti,sec){qeSeq().getVideoTrackAt(ti).razor(tc(sec));return "ok";}
function cutOut(a,b){var s=seq();var q=qeSeq();var gone=[];var i,j,t,c;for(i=0;i<s.videoTracks.numTracks;i++){if(s.videoTracks[i].clips.numItems){q.getVideoTrackAt(i).razor(tc(a));q.getVideoTrackAt(i).razor(tc(b));}}for(i=0;i<s.audioTracks.numTracks;i++){if(s.audioTracks[i].clips.numItems){q.getAudioTrackAt(i).razor(tc(a));q.getAudioTrackAt(i).razor(tc(b));}}
var h=0.5/fps();function scan(tr){for(j=0;j<tr.clips.numItems;j++){c=tr.clips[j];if(c.start.seconds>=a-h&&c.end.seconds<=b+h){gone.push(c);}}}for(i=0;i<s.audioTracks.numTracks;i++){scan(s.audioTracks[i]);}for(i=0;i<s.videoTracks.numTracks;i++){scan(s.videoTracks[i]);}
for(i=0;i<gone.length;i++){gone[i].remove(i==gone.length-1,i==gone.length-1);}return gone.length?"ok":"ERR nothing between "+a+" and "+b;}
function prop(clip,ci,name){var c=clip.components[ci];for(var i=0;i<c.properties.numItems;i++){if(c.properties[i].displayName==name){return c.properties[i];}}return null;}
function addTracks(nv,na){var s=seq();var q=qeSeq();if(s.videoTracks.numTracks<nv){q.addTracks(nv-s.videoTracks.numTracks,s.videoTracks.numTracks,0);}if(s.audioTracks.numTracks<na){q.addTracks(0,0,na-s.audioTracks.numTracks,1,s.audioTracks.numTracks);}return "V="+s.videoTracks.numTracks+" A="+s.audioTracks.numTracks;}
'''


class BridgeError(RuntimeError):
    pass


HELP = '''Premiere is not answering on %s.
  1. Open Premiere Pro with a project.
  2. Open the panel: Window > Extensions > Claude Bridge. It must say "LISTENING - engine OK".
  3. No "Claude Bridge" in that menu? Run install.sh from the skill folder, then quit and reopen Premiere.''' % BRIDGE


def send(script, timeout=60):
    """Run raw ExtendScript in Premiere and return the result as a string."""
    req = urllib.request.Request(BRIDGE + '/eval', data=script.encode(), headers={'Content-Type': 'text/plain'})
    try:
        return str(json.load(urllib.request.urlopen(req, timeout=timeout)).get('result'))
    except (urllib.error.URLError, OSError) as e:
        raise BridgeError(HELP + '\n  (' + str(e) + ')')


def ping():
    try:
        return json.load(urllib.request.urlopen(BRIDGE + '/ping', timeout=4))
    except Exception as e:
        return {'ok': False, 'error': str(e)}


def js(body, sequence='', timeout=60):
    """Run a function body with the PRELUDE helpers available. An exception comes back as 'ERR ...'."""
    return send(PRELUDE.replace('%SEQ%', sequence) + '\n(function(){try{' + body + '}catch(e){return "ERR "+e.toString();}})();', timeout)


INFO = '''if(!app.project){return "ERR no project open";}var o="project="+app.project.name+"||path="+app.project.path+"||active="+(app.project.activeSequence?app.project.activeSequence.name:"none");
var ss=app.project.sequences;for(var i=0;i<ss.numSequences;i++){var s=ss[i];var v="";for(var a=0;a<s.videoTracks.numTracks;a++){v+=(a?",":"")+s.videoTracks[a].clips.numItems;}var u="";for(var b=0;b<s.audioTracks.numTracks;b++){u+=(b?",":"")+s.audioTracks[b].clips.numItems;}
o+="||sequence="+s.name+" | "+(Math.round(TICKS/Number(s.timebase)*100)/100)+" fps | "+(Math.round(Number(s.end)/TICKS*100)/100)+" s | "+s.frameSizeHorizontal+"x"+s.frameSizeVertical+" | clips per video track "+v+" | clips per audio track "+u;}
var n=0;function walk(b,d){for(var i=0;i<b.children.numItems&&n<120;i++){var c=b.children[i];n++;var m="";try{if(c.type!=2){m=c.getMediaPath();}}catch(e){}o+="||item="+d+c.name+(c.type==2?"/":"")+(m?" <- "+m:"");if(c.type==2){walk(c,d+c.name+"/");}}}walk(app.project.rootItem,"");return o;'''


def info():
    return js(INFO).split('||')


# ---------------------------------------------------------------- the pointer overlay (macOS)
def pointers_binary():
    """Path of the overlay program, building it from pointers.swift when it is missing or out of date. None if it cannot run here."""
    src = SKILL / 'pointers' / 'pointers.swift'; out = SKILL / 'pointers' / 'pointers'
    if platform.system() != 'Darwin':
        print('pointers: the overlay is macOS only, editing without it'); return None
    if out.exists() and out.stat().st_mtime >= src.stat().st_mtime: return out
    if not shutil.which('swiftc'):
        print('pointers: swiftc not found (run: xcode-select --install), editing without the overlay'); return None
    r = subprocess.run(['swiftc', '-O', str(src), '-o', str(out)], capture_output=True, text=True)
    if r.returncode != 0:
        print('pointers: build failed, editing without the overlay\n' + r.stderr[-600:]); return None
    return out


class Pointers:
    def __init__(self, enabled=True, flags=()):
        self.proc = None
        if not enabled: return
        b = pointers_binary()
        if b: self.proc = subprocess.Popen([str(b), '--exit-on-eof', *flags], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True)

    def say(self, line):
        if not self.proc: return
        try:
            self.proc.stdin.write(line + '\n'); self.proc.stdin.flush()
        except (BrokenPipeError, OSError):          # stopped from the menu bar: keep editing without it
            self.proc = None

    def go(self, tag, zone, x, y, carry=False):
        self.say('go %s %s %.3f %.3f%s' % (tag.replace(' ', '-'), zone, min(1, max(0, x)), min(1, max(0, y)), ' carry' if carry else ''))

    def stop(self):
        if not self.proc: return
        p, self.proc = self.proc, None
        try:
            p.stdin.write('quit\n'); p.stdin.flush(); p.wait(timeout=2)
        except Exception:
            p.terminate()


PANELS = ('timeline', 'bin', 'program', 'controls', 'meters', 'tools')


class Session:
    """One edit. Pointers come up by default and close when the block ends.

    pointers   True / False; default: on, unless the environment has PPRO_POINTERS=0
    sequence   name of the sequence to edit (it is made the active one); default: the active sequence
    wait       seconds the pointers idle before the first edit (time to press record)
    hold       seconds they stay after the last edit
    pace       multiplies every pause: 2 = slower and easier to follow, 0 = as fast as Premiere allows
    """

    def __init__(self, pointers=None, sequence='', wait=1.5, hold=3.0, pace=1.0, pointer_flags=()):
        if pointers is None: pointers = os.environ.get('PPRO_POINTERS', '1') not in ('0', 'false', 'off', 'no')
        self.want_pointers = pointers; self.sequence = sequence; self.wait = wait; self.hold = hold; self.pace = pace; self.flags = pointer_flags
        self.problems = {}; self.edits = 0; self.steps = 0; self.swarm = Pointers(False)

    def __enter__(self):
        if not ping().get('ok'): raise BridgeError(HELP)
        if self.sequence:
            r = self.js('var s=seq();if(!s){return "ERR no sequence called "+SEQNAME;}app.project.activeSequence=s;return "ok";')
            if r != 'ok': raise BridgeError(r)
        self.refresh()
        self.swarm = Pointers(self.want_pointers, self.flags)
        if self.swarm.proc: time.sleep(self.wait)
        self.t0 = time.time()
        return self

    def __exit__(self, kind, err, tb):
        if kind is None:
            print('%d edits (%d steps) in %.1f s, problems: %s' % (self.edits, self.steps, time.time() - self.t0, self.problems or 0))
            if self.swarm.proc: time.sleep(self.hold)
        self.swarm.stop()
        return False

    def js(self, body, timeout=60):
        return js(body, self.sequence, timeout)

    def refresh(self):
        """Re-read the sequence length and track counts (call it after adding tracks or changing the length)."""
        r = self.js('var s=seq();if(!s){return "ERR no active sequence";}return s.name+"||"+(Number(s.end)/TICKS)+"||"+s.videoTracks.numTracks+"||"+s.audioTracks.numTracks+"||"+fps();')
        if r.startswith('ERR') or r.count('||') != 4: raise BridgeError('Could not read the sequence: ' + r)
        name, dur, nv, na, f = r.split('||')
        self.name = name; self.duration = max(float(dur), 0.001); self.nv = int(nv); self.na = int(na); self.fps = float(f)

    def spot(self, track=None, at=None, panel=None, x=None, y=None):
        """Where on screen an edit happens: (zone, fx, fy), each 0...1 inside the zone."""
        if track:
            kind = track[0].lower(); i = max(0, int(track[1:]) - 1)
            fx = 0.02 + 0.96 * min(1.0, max(0.0, (at or 0) / self.duration))
            if kind == 'v': fy = 0.45 - i * min(0.065, 0.40 / max(1, self.nv - 1))      # V1 sits just above the middle of the timeline panel
            else: fy = 0.54 + i * min(0.055, 0.40 / max(1, self.na - 1))               # A1 just below it
            return 'timeline', (fx if x is None else x), (fy if y is None else y)
        zone = panel if panel in PANELS else 'timeline'
        return zone, (random.uniform(0.15, 0.85) if x is None else x), (random.uniform(0.15, 0.85) if y is None else y)

    def step(self, tag, body=None, track=None, at=None, panel=None, x=None, y=None, carry=False, label=None, pause=0.07, timeout=60):
        """Move the pointer called `tag`, then run the ExtendScript `body` (optional: a move with no edit).

        track='V2' + at=seconds  -> that spot on the timeline (the whole sequence must fit the timeline panel: press the backslash key)
        panel='bin' | 'program' | 'controls' | 'meters' | 'tools' | 'timeline'  -> somewhere in that panel (x, y = 0...1 to choose where)
        carry=True  -> the pointer drags a small clip chip, for anything dropped onto the timeline
        Returns what the body returned. A result starting with ERR is counted in self.problems, and the edit goes on."""
        zone, fx, fy = self.spot(track, at, panel, x, y)
        self.steps += 1
        self.swarm.go(tag, zone, fx, fy, carry)
        if self.swarm.proc and pause * self.pace > 0: time.sleep(pause * self.pace)
        if body is None: return None
        self.edits += 1
        r = self.js(body, timeout)
        if r.startswith('ERR') or r.startswith('EvalScript error'):
            key = (label or tag) + ': ' + r[:70]; self.problems[key] = self.problems.get(key, 0) + 1
        return r


if __name__ == '__main__':
    a = sys.argv[1:]; c = a[0] if a else 'ping'
    try:
        if c == 'ping':
            r = ping(); print(r if r.get('ok') else HELP + '\n  (' + r.get('error', '') + ')'); sys.exit(0 if r.get('ok') else 1)
        elif c == 'info':
            print('\n'.join(info()))
        elif c == 'eval':
            src = pathlib.Path(a[2]).read_text() if len(a) > 2 and a[1] == '-f' else ' '.join(a[1:])
            print(send(src))
        elif c == 'pointers':
            b = pointers_binary()
            if b: subprocess.run([str(b), *a[1:]])
        else:
            print(__doc__)
    except BridgeError as e:
        print(e); sys.exit(1)
