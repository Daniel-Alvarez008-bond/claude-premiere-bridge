# Premiere ExtendScript: checked recipes

Everything here was run through the bridge in **Premiere Pro 2026 (26.5) on macOS**. Other versions mostly behave the same; test a call with `python3 scripts/ppro.py eval '...'` when in doubt.

Recipes marked **helper** are functions `ppro.py` puts in front of every script sent with `ppro.js()` / `Session.step()`. With `ppro.py eval` (raw script) they are not there.

## Helpers

| Helper | Does |
|---|---|
| `seq()` | The sequence being edited (active one, or the one named in `Session(sequence=...)`) |
| `findItem("name")` | Project item by name, searching bins too |
| `track("v"\|"a", i)` | Track object, `i` from 0 (V1 = 0) |
| `put(kind, ti, "item name", atSec, inSec, outSec)` | Overwrite an item onto a track at a time. `outSec > 0` uses the source range in..out; `0, 0` uses the whole item |
| `clipAt(kind, ti, sec)` | The clip under a time on a track (standard API object) |
| `qeAt(kind, ti, sec)` | The same clip as a QE object (needed for transitions and effects) |
| `razor(ti, sec)` | Cut video track `ti` at a time |
| `cutOut(fromSec, toSec)` | Remove that section from every track and close the gap |
| `prop(clip, componentIndex, "Name")` | An effect property, e.g. `prop(c, 1, "Scale")` |
| `head(sec)` | Move the playhead |
| `tc(sec)` | Seconds to the timecode string QE wants |
| `fps()` | Sequence frame rate |
| `addTracks(nVideo, nAudio)` | Make sure the sequence has at least that many tracks |
| `sel(clip)` | Select a clip (shows its effects in Effect Controls) |

## Reading

```js
app.version                         // "26.5.2"
app.project.name; app.project.path
app.project.activeSequence.name
var s = seq();
s.videoTracks.numTracks; s.audioTracks.numTracks
s.videoTracks[0].clips.numItems; s.videoTracks[0].transitions.numItems
Number(s.end) / TICKS               // length in seconds (s.end is a tick string)
TICKS / Number(s.timebase)          // frame rate
s.frameSizeHorizontal; s.frameSizeVertical
var c = s.videoTracks[0].clips[0];
c.name; c.start.seconds; c.end.seconds; c.inPoint.seconds; c.outPoint.seconds; c.duration.seconds; c.projectItem.name
findItem("clip.mp4").getMediaPath() // file on disk
```

`python3 scripts/ppro.py info` prints all of this at once.

## Project and sequences

```js
app.project.importFiles(["/full/path/a.mp4", "/full/path/b.png"], true, app.project.rootItem, false);
app.project.createNewSequenceFromClips("My sequence", [findItem("a.mp4")], app.project.rootItem);   // settings match the clip; becomes active
app.project.activeSequence = someSequence;       // also brings it to the front in the timeline
findItem("a.mp4").setColorLabel(4);              // 0-15, colours the clip in bin and timeline
```

Duplicate a sequence and work on the copy (`clone()` gives no handle to the copy, so find the new ID):

```js
var o = seq(); var ss = app.project.sequences; var old = "|";
for (var i = 0; i < ss.numSequences; i++) { old += ss[i].sequenceID + "|"; }
o.clone();
var c = null; for (var j = 0; j < ss.numSequences; j++) { if (old.indexOf("|" + ss[j].sequenceID + "|") < 0) { c = ss[j]; } }
c.name = o.name + " (Claude edit)"; app.project.activeSequence = c;
```

## Cutting

```js
razor(0, 12.4);                                             // helper: cut V1 at 12.4 s (video only, audio stays whole)
qeSeq().getAudioTrackAt(0).razor(tc(12.4));                 // cut A1
cutOut(10, 12.25);                                          // helper: remove 10-12.25 s everywhere and close the gap
clipAt("v", 0, 5).remove(false, false);                     // delete a clip, leave the gap
var t = new Time(); t.seconds = -2; clipAt("v", 0, 33).move(t);   // slide a clip 2 s earlier
```

How the gap closes: razor both ends on video and audio, remove the pieces without ripple, and remove the **last** piece with `remove(true, true)`. A ripple remove does nothing while another track still has media in that section. `cutOut` does all of this. Removing several sections: start from the end of the timeline.

Cuts land on frame boundaries (12.4 s at 23.976 fps becomes 12.387). At 29.97 / 59.94 fps with drop-frame timecode, check where the first cut landed before making fifty more.

## Placing clips and stills

```js
put("v", 1, "broll.mp4", 8.0, 2.0, 4.5);     // V2 at 8 s, source 2.0-4.5 s
put("v", 2, "caption_001.png", 4.2, 0, 1.6); // a still for 1.6 s (the in/out range sets a still's length)
put("a", 1, "whoosh.mp3", 7.9, 0, 0);        // whole sound on A2
```

`put` uses `track.overwriteClip(item, seconds)`, which replaces what is under it on that track. `insertClip` (same arguments, not re-checked here) pushes later clips along instead. Add tracks first when the track does not exist: `addTracks(3, 4)`.

Captions and titles: render a transparent PNG per card at the sequence frame size (Pillow), import, and `put` each at its word time. That is far more reliable than scripting Premiere's text tools.

## Transitions and effects (QE)

```js
var it = qeAt("v", 0, 12.2);                                                    // the clip that ENDS at the cut
it.addTransition(qe.project.getVideoTransitionByName("Cross Dissolve"), true, tc(0.4));   // true = at the end of the clip, false = at its start
qeAt("v", 0, 5).addVideoEffect(qe.project.getVideoEffectByName("Lumetri Color"));
qeAt("a", 0, 5).addAudioEffect(qe.project.getAudioEffectByName("Parametric Equalizer"));  // also "DeEsser", "Hard Limiter"
qe.project.getVideoTransitionList();   // every name available: Cross Dissolve (Legacy), Dip to White (Legacy), Cross Zoom (Legacy), Push (Legacy), Morph Cut, ...
qe.project.getVideoEffectList(); qe.project.getAudioEffectList();
```

A wrong name gives a null effect and a silent no-op, so read the list when unsure. Remove transitions with `track("v",0).transitions[i].remove(false, false)`.

## Motion, opacity, volume, keyframes

Video clip components: `[0]` Opacity (Opacity, Blend Mode), `[1]` Motion (Position, Scale, Rotation, Anchor Point, Crop ...). Added effects follow from `[2]`. Audio clip: `[0]` Volume (Level).

```js
var c = clipAt("v", 0, 2);
prop(c, 1, "Scale").setValue(120, true);            // percent
prop(c, 1, "Position").setValue([0.5, 0.4], true);  // fractions of the frame, [0.5, 0.5] = centre
prop(c, 0, "Opacity").setValue(80, true);
var L = prop(clipAt("a", 0, 2), 0, "Level"); L.setValue(Math.pow(10, (-6 - 15) / 20), true);   // -6 dB (0 dB reads as 0.1778)

var p = prop(c, 1, "Scale"); p.setTimeVarying(true);                // a push-in over the first 0.6 s of the clip
var t0 = c.inPoint.seconds;                                         // keyframe times are in SOURCE time, from the clip's in point
p.addKey(t0 + 0.05); p.setValueAtKey(t0 + 0.05, 100, true);
p.addKey(t0 + 0.6);  p.setValueAtKey(t0 + 0.6, 112, true);
```

## Markers

```js
var m = seq().markers.createMarker(12.5); m.name = "Take 2"; m.setColorByIndex(3, 0);
```

Do not assign `m.end`; it throws "Illegal Parameter type".

## Export and save

```js
var preset = app.path + "Contents/MediaIO/systempresets/4E49434B_48323634/00 - Match Source - High bitrate.epr";   // H.264, macOS
seq().exportAsMediaDirect("/full/path/out.mp4", preset, 0);     // returns "No Error"; blocks until done; no Media Encoder needed
app.project.save();                                             // standard call, not re-checked for this release
```

Give export a long timeout (`ppro.js(body, timeout=1800)`). On Windows the presets are under `C:\Program Files\Adobe\Adobe Premiere Pro <year>\MediaIO\systempresets\` and `exportAsMediaDirect` needs backslash paths there.

## Traps

- `EvalScript error.` with no detail: a syntax error, or modern JavaScript the engine does not know.
- Do not load a JSON polyfill or anything with exotic regular expressions into the engine. It has poisoned the whole engine before, so that even `2+2` failed until Premiere was restarted. Return `a||b||c` strings and split them in Python.
- `qe.project.getActiveSequence()` is the sequence in front, whatever `seq()` returns. Keep them the same.
- `exportFramePNG` and `app.project.openSequence()` have frozen the bridge; export a clip and pull frames with ffmpeg instead.
- Still images need their in/out range set before they are placed (`put` does it).
- After changing the panel's files, quit and reopen Premiere. After Premiere restarts, the user must have the panel open again.
- The panel answers one script at a time. Do not send edits in parallel.
