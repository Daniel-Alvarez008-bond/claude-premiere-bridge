# The pointer overlay

`pointers/pointers` is a small macOS program (source: `pointers/pointers.swift`, built by `install.sh` or on first use). It draws a transparent, click-through, always-on-top layer over the main screen with labelled mouse pointers on it. It cannot click, type or read the screen. `Session` starts it, tells it where each edit is happening, and closes it at the end.

## Tags

A tag is the label on a pointer. Use any short word; a tag the overlay has not seen gets a new pointer the first time a step uses it. Spaces become dashes.

The overlay starts with these, wandering inside their panel until a step calls them:

| Panel | Tags |
|---|---|
| timeline | cuts, markers, captions, pops, flashes, whoosh, clicks, impacts, risers, music, ambience, b-roll, transitions, progress, titles, grade, sync, trim |
| bin | footage, sfx-pick, import, gfx-pick |
| program | color, preview |
| controls | zoom, eq, keyframes, lumetri |
| meters | levels |
| tools | razor |

Pick tags that match the edit. A good run uses 10 to 20 different ones.

## Where a step points

- `track='V3', at=12.5`: the timeline, at that time on that track. Across = time / sequence length; down = V1 just above the middle of the panel and higher video tracks above it, A1 just below the middle and later audio tracks below.
- `panel='bin'` (also `program`, `controls`, `meters`, `tools`, `timeline`): a random spot in that panel, or the spot you give with `x=`, `y=` (0 to 1 across and down the panel).
- `carry=True`: the pointer drags a small clip chip. Use it for anything placed on the timeline; a move to the bin first (`s.step('footage', None, panel='bin')`) makes it read as "picked up, then dropped".
- A step with `body=None` only moves the pointer.

## Lining it up with Premiere

The layout in `pointers/zones.json` matches Premiere's default **Editing** workspace, full screen on the main display (Window > Workspaces > Editing, then Reset to Saved Layout). The timeline should show the whole sequence: click the timeline and press `\`.

To check, run `python3 scripts/ppro.py pointers --show-zones --seconds 20` with Premiere in front: each panel's area is outlined in red. If the outlines miss the panels, edit `zones.json`. Each entry is a rectangle in fractions of the screen from the top-left corner (`x`, `y`, `w`, `h`), with `agents` listing the tags that start there and `drag` saying whether idle pointers make dragging moves.

You cannot see the user's screen. If they say the pointers are off, ask them for a screenshot (Cmd+Shift+3) and adjust `zones.json` from it.

## Flags

`python3 scripts/ppro.py pointers [flags]` runs the overlay alone, and `Session(pointer_flags=(...))` passes flags during an edit.

| Flag | Effect |
|---|---|
| `--seconds N` | Close after N seconds |
| `--count N` | Start with only N of the built-in pointers |
| `--speed X` | Faster (above 1) or slower idle movement |
| `--scripted-only` | Pointers stay still until a step calls them: only real edits move anything |
| `--show-zones` | Outline the panel areas |
| `--zones file.json` | Use another layout file |

Stop it at any time from the dot in the menu bar (Stop pointers). The edit carries on without it.
