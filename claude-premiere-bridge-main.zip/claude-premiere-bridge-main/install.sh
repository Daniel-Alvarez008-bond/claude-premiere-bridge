#!/bin/bash
# Installs the Claude Bridge panel into Premiere Pro and builds the pointer overlay. macOS. Safe to run again.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
if [ "$(uname)" != "Darwin" ]; then echo "This installer is for macOS. Windows steps are in the README."; exit 1; fi

EXT="$HOME/Library/Application Support/Adobe/CEP/extensions/com.claude.ppro.bridge"
mkdir -p "$HOME/Library/Application Support/Adobe/CEP/extensions"
rm -rf "$EXT"
cp -R "$DIR/extension/com.claude.ppro.bridge" "$EXT"
echo "1/3 panel copied to: $EXT"

# Adobe apps only load unsigned panels when this switch is on (undo: defaults delete com.adobe.CSXS.<n> PlayerDebugMode)
for v in 9 10 11 12 13 14 15 16; do defaults write com.adobe.CSXS.$v PlayerDebugMode 1; done
echo "2/3 Premiere is allowed to load the panel"

if command -v swiftc >/dev/null 2>&1; then
  swiftc -O "$DIR/pointers/pointers.swift" -o "$DIR/pointers/pointers" && echo "3/3 pointer overlay built"
else
  echo "3/3 SKIPPED: no Swift compiler. Run 'xcode-select --install', then run this installer again to get the pointers."
fi

cat <<'EOF'

Done. Now:
  1. Quit Premiere Pro completely and open it again, with a project.
  2. Window > Extensions > Claude Bridge. The panel must say "LISTENING - engine OK".
  3. In Claude Code say: "edit this video in Premiere".
EOF
