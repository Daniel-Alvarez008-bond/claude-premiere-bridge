# Claude Premiere Bridge

A skill for [Claude Code](https://claude.com/claude-code) that lets Claude edit inside your real Adobe Premiere Pro, while a swarm of labelled mouse pointers shows every edit on screen as it happens.

You say **"edit this video"**. Claude reads your timeline, plans the edit, and makes it in Premiere: cuts, captions, transitions, zooms, colour, sound. The pointers come up by default, one per job ("cuts", "captions", "music", ...), each flying to the spot its edit lands.

![The pointer overlay on its own](assets/pointers.jpg)

*The overlay on a plain background. In use it sits on top of Premiere.*

## What you need

- A Mac with **Adobe Premiere Pro**. Tested on Apple silicon with Premiere Pro 2026 (26.5) and macOS 26.
- **Claude Code**.
- Python 3 and Apple's command line tools (`xcode-select --install`). Most Macs with git already have both.

Windows: the bridge works, the pointers do not. See [Windows](#windows).

## Install

Paste this into Terminal:

```bash
git clone https://github.com/GitSiddhantag/claude-premiere-bridge.git ~/.claude/skills/premiere-bridge
~/.claude/skills/premiere-bridge/install.sh
```

Then:

1. Quit Premiere Pro completely and open it again, with a project.
2. Open **Window > Extensions > Claude Bridge**. The panel must say **LISTENING - engine OK**.
3. Start a new Claude Code session.

You can also just tell Claude Code: *"Install the skill from https://github.com/GitSiddhantag/claude-premiere-bridge"*.

## Use it

Put a clip on the timeline and talk to Claude Code:

- "Edit this video in Premiere."
- "Cut out the pauses and add captions."
- "Add a zoom on every cut and a whoosh under each one."
- "What's on my timeline?"
- "Export it to my Desktop."

Claude tells you the plan, the pointers appear, and the timeline fills up while you watch. Keep the Claude Bridge panel open while you work.

### See it in 20 seconds

With a clip on V1 of the open sequence:

```bash
python3 ~/.claude/skills/premiere-bridge/examples/showcase.py
```

It duplicates your sequence and edits the copy: markers, cuts, transitions, push-in zooms, colour, a voice effect chain. Your original sequence is not changed. Add `--transcript words.json` (a Whisper word-timestamp file) to cut on the speaker's pauses and add word captions.

## The pointers

The pointers are an overlay: a transparent layer on top of your screen. They **do not click anything**. Claude makes each edit by script, and sends a pointer to the place that edit happens, so what you see is what is really being done, when it is done.

- **On by default.** Say "no pointers" and Claude edits without them.
- **Recording:** use QuickTime or Cmd+Shift+5 to record the screen, or film the laptop. Ask Claude to "wait 5 seconds before starting" so you can press record.
- **Lining up:** the pointers expect Premiere full screen in the default **Editing** workspace, with the whole sequence visible in the timeline (press `\`). If they look off, ask Claude to "line up the pointers" or see [references/pointers.md](references/pointers.md).
- **Stop them** any time from the dot in the menu bar.

## What Claude can do through the bridge

Checked in Premiere Pro 2026:

- Read the project: sequences, tracks, clips, times, source files
- Import media, create and duplicate sequences, add tracks
- Razor cuts, remove a section and close the gap, move clips
- Place b-roll, stills, captions, sound effects and music at exact times
- Transitions, video effects (Lumetri and the rest), audio effects
- Position, scale, opacity, volume, keyframes
- Markers and colour labels
- Export H.264 without Media Encoder

The recipes are in [references/extendscript.md](references/extendscript.md).

## Is it safe?

- **It stays on your computer.** The panel listens on `127.0.0.1` only, and refuses requests that come from a web page. Nothing is uploaded by the bridge.
- **It can do whatever a Premiere script can do**, for any program on your Mac that talks to it. Close the Claude Bridge panel when you are not using it; closed means off.
- **Your original stays.** Claude works on a copy of the sequence unless you ask otherwise, and does not save or export unless you ask.
- **The installer turns on Adobe's "PlayerDebugMode"**, the switch that lets Adobe apps load panels that are not from the Adobe store. It applies to all such panels, not only this one. To turn it off again, see Uninstall.

## Uninstall

```bash
rm -rf "$HOME/Library/Application Support/Adobe/CEP/extensions/com.claude.ppro.bridge" ~/.claude/skills/premiere-bridge
for v in 9 10 11 12 13 14 15 16; do defaults delete com.adobe.CSXS.$v PlayerDebugMode 2>/dev/null; done
```

Skip the second line if you use other unsigned Adobe panels.

## Windows

The panel was first built on Windows and the bridge works there. The pointer overlay is macOS only, so Claude edits without it. There is no installer yet:

1. Copy `extension\com.claude.ppro.bridge` to `%APPDATA%\Adobe\CEP\extensions\`.
2. In the registry, under `HKEY_CURRENT_USER\Software\Adobe\CSXS.11` (and `CSXS.12` and later, for newer Premiere versions), add a string value `PlayerDebugMode` = `1`.
3. Copy this repo to `%USERPROFILE%\.claude\skills\premiere-bridge`, restart Premiere, open Window > Extensions > Claude Bridge.

This release was tested on macOS only.

## How it works

```
Claude Code  --HTTP, 127.0.0.1:3999-->  Claude Bridge panel (inside Premiere)  --ExtendScript-->  your project
     |
     '--stdin-->  pointer overlay (transparent window on top of the screen)
```

- `extension/`: the panel, a CEP extension running a small local HTTP server that executes the ExtendScript it receives.
- `scripts/ppro.py`: the client. Its `Session` runs an edit step by step: move a pointer, make the edit.
- `pointers/pointers.swift`: the overlay, built on your Mac by the installer.
- `SKILL.md` and `references/`: what Claude reads to know how to drive it all.

## Built with

Python (standard library), Swift/AppKit, and a CEP panel. Made with [Claude Code](https://claude.com/claude-code).

Adobe and Premiere Pro are trademarks of Adobe Inc. This project is not affiliated with or endorsed by Adobe or Anthropic.

## License

MIT
