/* ============================================================
   Claude Bridge - ExtendScript host for Adobe Premiere Pro
   Minimal + ExtendScript-safe (no exotic regex / json2).
   ============================================================ */

function bridgePing() {
    var v = "", p = "none", s = "none";
    try { v = app.version; } catch (e) {}
    try { if (app.project) { p = app.project.name; } } catch (e2) {}
    try { if (app.project && app.project.activeSequence) { s = app.project.activeSequence.name; } } catch (e3) {}
    return "version=" + v + "||project=" + p + "||sequence=" + s;
}

function bridgeProjectInfo() {
    if (!app.project) { return "ERROR: no project open"; }
    var out = "project=" + app.project.name + "||path=" + app.project.path;
    try {
        var seqs = [];
        for (var i = 0; i < app.project.sequences.numSequences; i++) {
            var s = app.project.sequences[i];
            seqs.push(s.name + "(" + s.videoTracks.numTracks + "v/" + s.audioTracks.numTracks + "a)");
        }
        out += "||sequences=" + seqs.join(", ");
    } catch (e) { out += "||seqError=" + e.toString(); }
    try {
        var items = [];
        var root = app.project.rootItem;
        for (var j = 0; j < root.children.numItems; j++) {
            items.push(root.children[j].name);
        }
        out += "||items=" + items.join(", ");
    } catch (e2) { out += "||itemError=" + e2.toString(); }
    return out;
}

$.writeln("Claude Bridge host.jsx loaded ok");
"HOST_LOADED";
