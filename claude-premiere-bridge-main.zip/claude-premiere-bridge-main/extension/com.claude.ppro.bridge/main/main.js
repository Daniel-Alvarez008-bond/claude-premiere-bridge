/* ============================================================
   Claude Bridge - panel runtime: a local HTTP door into Premiere Pro
   POST ExtendScript to http://127.0.0.1:3999/eval and get the result back.
   ============================================================ */
(function () {
    "use strict";

    var VERSION = "1.1.0";
    var PORT = 3999;
    var HOST = "127.0.0.1";
    var http = require("http");

    var elState = document.getElementById("state");
    var elPort = document.getElementById("port");
    var elLast = document.getElementById("last");
    var elResult = document.getElementById("result");
    var elCount = document.getElementById("count");
    var count = 0;

    function setState(txt, good) {
        if (elState) { elState.textContent = txt; elState.className = good ? "ok" : "bad"; }
    }
    function logLast(cmd, result) {
        count++;
        if (elCount) { elCount.textContent = String(count); }
        if (elLast) { elLast.textContent = cmd; }
        if (elResult) { elResult.textContent = result; }
    }

    var cep = window.__adobe_cep__;

    /* Host ExtendScript injected at runtime (independent of ScriptPath). */
    var HOST_SCRIPT =
        "function bridgePing(){var v='',p='none',s='none';" +
        "try{v=app.version}catch(e){}" +
        "try{if(app.project){p=app.project.name}}catch(e2){}" +
        "try{if(app.project&&app.project.activeSequence){s=app.project.activeSequence.name}}catch(e3){}" +
        "return 'version='+v+'||project='+p+'||sequence='+s;}" +
        "'HOST_INJECTED';";

    function rawEval(script) {
        return new Promise(function (resolve) {
            if (!cep || typeof cep.evalScript !== "function") {
                resolve("NO_ADOBE_CEP_BINDING");
                return;
            }
            try {
                cep.evalScript(script, function (res) { resolve(res); });
            } catch (e) {
                resolve("PANEL_EXCEPTION: " + e.toString());
            }
        });
    }

    function hostEnv() {
        try { return cep.getHostEnvironment(); } catch (e) { return "{}"; }
    }

    function sendJSON(res, code, obj) {
        var body = JSON.stringify(obj);
        res.writeHead(code, {
            "Content-Type": "application/json",
            "Content-Length": Buffer.byteLength(body)
        });
        res.end(body);
    }

    /* Only programs on this computer may talk to the panel. A web page open in a browser must not:
       browsers put an Origin header on cross-site requests, and a DNS-rebinding page arrives with a foreign Host. */
    function allowed(req) {
        if (req.headers.origin) { return false; }
        var h = String(req.headers.host || "").toLowerCase();
        return h === HOST + ":" + PORT || h === "localhost:" + PORT;
    }

    var server = http.createServer(function (req, res) {
        var url = req.url.split("?")[0];
        var buf = "";
        if (!allowed(req)) {
            req.resume();
            sendJSON(res, 403, { ok: false, error: "Claude Bridge only answers local programs, not web pages." });
            return;
        }
        req.on("data", function (d) { buf += d; });
        req.on("end", function () {

            if (req.method === "GET" && (url === "/ping" || url === "/")) {
                rawEval("bridgePing()").then(function (r) {
                    sendJSON(res, 200, { ok: true, bridge: "premiere", version: VERSION, host: r });
                });
                return;
            }

            // Full diagnostics of the CEP <-> ExtendScript link
            if (url === "/diag") {
                var env = hostEnv();
                rawEval("2+2").then(function (r2) {
                    rawEval(HOST_SCRIPT).then(function (inj) {
                        rawEval("typeof bridgePing").then(function (tp) {
                            sendJSON(res, 200, {
                                ok: true,
                                cepBindingPresent: !!(cep && typeof cep.evalScript === "function"),
                                hostEnvironment: env,
                                eval_2plus2: r2,
                                inject_host: inj,
                                typeof_bridgePing: tp
                            });
                        });
                    });
                });
                return;
            }

            // Re-inject host functions
            if (url === "/reload") {
                rawEval(HOST_SCRIPT).then(function (r) {
                    sendJSON(res, 200, { ok: true, reload: r });
                });
                return;
            }

            if (req.method === "POST" && url === "/eval") {
                var script = buf;
                try {
                    var parsed = JSON.parse(buf);
                    if (parsed && typeof parsed.script === "string") { script = parsed.script; }
                } catch (e) { /* raw script */ }
                logLast(script.substring(0, 140), "running...");
                rawEval(script).then(function (r) {
                    logLast(script.substring(0, 140), String(r).substring(0, 400));
                    sendJSON(res, 200, { ok: true, result: r });
                });
                return;
            }

            sendJSON(res, 404, { ok: false, error: "Unknown route: " + req.method + " " + url });
        });
    });

    server.on("error", function (e) { setState("Server error: " + e.message, false); });

    server.listen(PORT, HOST, function () {
        if (elPort) { elPort.textContent = HOST + ":" + PORT; }
        if (!cep || typeof cep.evalScript !== "function") {
            setState("LISTENING — but NO ExtendScript binding", false);
            return;
        }
        // Inject host functions, then verify engine responds
        rawEval(HOST_SCRIPT).then(function () {
            rawEval("2+2").then(function (r) {
                if (r === "4" || r === 4) { setState("LISTENING — engine OK", true); }
                else { setState("LISTENING — engine error (" + String(r).substring(0, 40) + ")", false); }
            });
        });
    });

})();
